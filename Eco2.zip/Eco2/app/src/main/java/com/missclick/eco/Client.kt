package layout

data class Client(val name: String)