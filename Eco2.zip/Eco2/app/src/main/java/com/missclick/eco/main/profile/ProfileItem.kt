package com.missclick.eco.main.profile

data class ProfileItem(
    val firstName: String,
    val lastName: String
)