package com.missclick.eco.main.profile

data class PositiveItem(
    val id: Int = 0,
    val action: String = "",
    val score: Int = 0,
    var time: String = ""
)